package com.uth.hn.operaciones_junit;

import java.util.Scanner;

/** 
 * Realizado Por Jose Carlos Cueva!
 *
 */
public class App 
{
    public static void main( String[] args )
   
    {
    	Scanner lee = new Scanner(System.in);
    	
    	System.out.println("\n---REALICE UN PROGRAMA EN EL LENGUAJE JAVA TIPO CONSOLA QUE REALICE LAS SIGUIENTES OPERACIONES:---");
		
		boolean salir = false;
	       int opcion;
	        
	       while(!salir){
	            
	    	   System.out.println("\nMENU PRINCIPAL");
	    	   System.out.println("1. -->  Area de un círculo");
	    	   System.out.println("2. -->  Area de un cuadrado");
	    	   System.out.println("3. -->  Area de un rectángulo");
	           System.out.println("4. -->  Area de un triángulo");
	           System.out.println("5. --> Salir");
	            
	           System.out.println("\nEscribe una de las opciones");
	           opcion = lee.nextInt();
	            
	           switch(opcion){
	               case 1:
	            	   System.out.println("\nHas seleccionado la opcion 2: --> Area de un Círculo ");
	                   
	                   // Ingreso de datos
	           		
	           			System.out.println("----Calculando el Area de un Círculo----");
	            	   
	            	   // Solicitar al usuario que ingrese el radio del círculo
	                   System.out.print("Ingresa el radio del círculo: ");
	                   double radio = lee.nextDouble();

	                   // Calcular el área del círculo
	                   double area = Math.PI * Math.pow(radio, 2);

	                   // Imprimir el resultado
	                   System.out.println("El área del círculo con radio " + radio + " es " + area);
	                   break;
                    	    
                         
	               case 2:
	                   System.out.println("\nHas seleccionado la opcion 2: --> Area de un Cuadrado ");
	                   
	                   // Ingreso de datos
	           		
	           			System.out.println("----Calculando el Area de un Cuadrado----");
	           		
	           			System.out.println("\nIngrese el area: ");
	           			double a = lee.nextDouble();
	           		
	           			//proceso
	           		
	           			double area2 = a * a ;
	           		
	           			//salida de datos
	           		
	           			System.out.printf("\nEl Area de un Cuadrado es: %.2f",area2);
	                   break;
	                  
	                   
	               case 3:
	                   System.out.println("\nHas seleccionado la opcion 3: --> Area de un Rectángulo ");
	                   
	                   // Ingreso de datos
		           		
	           			System.out.println("----Calculando el Area de un Rectángulo----");
	                   
	                   // Solicitar al usuario que ingrese la longitud y el ancho del rectángulo
	                   System.out.print("\nIngresa la longitud del rectángulo: ");
	                   double longitud = lee.nextDouble();

	                   System.out.print("Ingresa el ancho del rectángulo: ");
	                   double ancho = lee.nextDouble();

	                   // Calcular el área del rectángulo
	                   double area3 = longitud * ancho;

	                   // Imprimir el resultado
	                   System.out.println("\nEl área del rectángulo es: " + area3);
	                   break;
	                   
	                 
	                case 4:
	                   System.out.println("\nHas seleccionado la opcion 4: --> Area de un Triángulo ");
	                   
	                   // Ingreso de datos
	           		
	           			System.out.println("----Calculando el Area de un triángulo----");
	           				
	           			System.out.println("\nIngrese la altura: ");
	           			double h = lee.nextDouble();
	           				
	           			System.out.println("\nIngrese la base: ");
	           				
	           			//proceso
	           			
	           			double b = lee.nextDouble();
	           				
	           			double area4 = b * h / 2;
	           			
	           			//salida de datos
	           				
	           			System.out.printf("\nEl Area de un Triángulo es: %.2f",area4);
	                   break;   
	                  
	               case 5:
	                   salir=true;
	                   break;
	                default:
    }

}
	    lee.close();
    }

    public static double area(double radio) {
        return Math.PI * Math.pow(radio, 2);
    }

    public static double area2(double lado) {
        
        
    	return lado * lado;
    	    }

    public static double area3(double longitud, double ancho) {
        return longitud * ancho;
    }

    public static double area4(double base, double altura) {
        
        
    	return (base * altura) / 2;
    	    }
    
   
}
