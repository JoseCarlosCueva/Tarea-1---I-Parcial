package com.uth.hn.operaciones_junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AppTest{ 
    
	@Before
	public void metodoTipoSetup() {
		System.out.println("Ejecutando metodo tipo setup antes de cada test...");
		}
	
	@BeforeClass
	public static void metodoTipoSetupClass() {
		System.out.println("Ejecutando metodo tipo setup class antes de todos los test...");
		App aplicacion = new App();
		aplicacion.main(null);
	}
	
	@Test
	public void areacirculo1() {
	    assertEquals(App.area(5), 78, 0.001);
	}

	@Test
	public void areacuadrado1() {
	    assertEquals(App.area2(2), 4, 0.0001);
	}
	
	@Test
	public void areacuadrado2() {
	    assertEquals(App.area2(3), 9, 0.0001);
	}
	
	@Test
	public void areacuadrado3() {
	    assertEquals(App.area2(9), 81, 0.0001);
	}
	
	@Test
	public void areacuadrado4() {
	    assertEquals(App.area2(6), 36, 0.0001);
	}
	@Test
	public void areacuadrado5() {
	    assertEquals(App.area2(7), 49, 0.0001);
	}

	@Test
	public void arearectangulo1() {
	    assertEquals(App.area3(20, 10), 200, 0.001);
	}
	
	@Test
	public void arearectangulo2() {
	    assertEquals(App.area3(20, 5), 100, 0.001);
	}
	
	@Test
	public void arearectangulo3() {
	    assertEquals(App.area3(20, 3), 60, 0.001);
	}

	@Test
	public void areatriangulo1() {
	    assertEquals(App.area4(30, 15), 225, 0.01);
	}
	
	@Test
	public void areatriangulo2() {
	    assertEquals(App.area4(30, 10), 150, 0.01);
	}
	
	@Test
	public void areatriangulo3() {
	    assertEquals(App.area4(30, 5), 75, 0.01);
	}

	
	@After
	public void metodoTearDown() {
		System.out.println("Ejecutando metodo tipo tear down después de cada test...");
	}
	
	@AfterClass
	public static void metodoTearDownClass() {
		System.out.println("Ejecutando metodo tipo tear down después de todos los test...");
	}
}

